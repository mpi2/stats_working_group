### R code from vignette source 'IMPCdata.Rnw'

###################################################
### code chunk number 1: R.hide
###################################################
library(IMPCdata)
getName("pipeline_stable_id","pipeline_name","MGP_001")


###################################################
### code chunk number 2: R.hide
###################################################
library(IMPCdata)
getName("gene_accession_id","gene_symbol","MGI:1931466")


###################################################
### code chunk number 3: R.hide
###################################################
library(IMPCdata)
getPhenCenters()
printPhenCenters()


###################################################
### code chunk number 4: R.hide
###################################################
library(IMPCdata)
getPipelines("WTSI")
getPipelines("WTSI",excludeLegacyPipelines=FALSE)
printPipelines("WTSI")


###################################################
### code chunk number 5: R.hide
###################################################
library(IMPCdata)
head(getProcedures("WTSI","MGP_001"),n=2)
printProcedures("WTSI","MGP_001",n=2)


###################################################
### code chunk number 6: R.hide
###################################################
library(IMPCdata)
head(getParameters("WTSI","MGP_001","IMPC_CBC_001"),n=2)
printParameters("WTSI","MGP_001","IMPC_CBC_001",n=2)


###################################################
### code chunk number 7: R.hide
###################################################
library(IMPCdata)
head(getStrains("WTSI","MGP_001","IMPC_CBC_001","IMPC_CBC_003_001"),n=2)
printStrains("WTSI","MGP_001","IMPC_CBC_001","IMPC_CBC_003_001",n=2)


###################################################
### code chunk number 8: R.hide
###################################################
library(IMPCdata)
head(getGenes("WTSI","MGP_001","IMPC_CBC_001","IMPC_CBC_003_001"),n=2)
printGenes("WTSI","MGP_001","IMPC_CBC_001",
"IMPC_CBC_003_001","MGI:2159965",n=2)


###################################################
### code chunk number 9: R.hide
###################################################
library(IMPCdata)
head(getAlleles("WTSI","MGP_001","IMPC_CBC_001",
"IMPC_CBC_003_001","MGI:5446362"),n=2)
printAlleles("WTSI","MGP_001","IMPC_CBC_001","IMPC_CBC_003_001",n=2)


###################################################
### code chunk number 10: R.hide
###################################################
library(IMPCdata)
getZygosities("WTSI","MGP_001","IMPC_CBC_001","IMPC_CBC_003_001",
StrainID="MGI:5446362",AlleleID="EUROALL:64")


###################################################
### code chunk number 11: R.hide (eval = FALSE)
###################################################
## library(IMPCdata)
## getIMPCTable("./IMPCData.csv","WTSI","MGP_001","IMPC_CBC_001")  


###################################################
### code chunk number 12: R.hide (eval = FALSE)
###################################################
## library(IMPCdata)
## IMPC_dataset1 <- getIMPCDataset("WTSI","MGP_001","IMPC_CBC_001",
## "IMPC_CBC_003_001","MGI:4431644") 


###################################################
### code chunk number 13: R.hide (eval = FALSE)
###################################################
## library(PhenStat)
## testIMPC1 <- PhenList(dataset=IMPC_dataset1,
## testGenotype="MDTZ",
## refGenotype="+/+",
## dataset.colname.genotype="Colony") 


